plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "fr.chris.telexiaomi"
    compileSdk = 34
    defaultConfig { applicationId = "fr.chris.telexiaomi"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources { excludes += setOf("META-INF/*") } }
}
dependencies {
    implementation("dev.mobile:dadb:1.2.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
