package fr.chris.telexiaomi

import android.app.Activity
import android.graphics.Color
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.View
import android.widget.*
import dadb.AdbKeyPair
import dadb.Dadb
import kotlinx.coroutines.*
import java.io.File

class MainActivity : Activity() {
    private var adb: Dadb? = null
    private val scope = CoroutineScope(Dispatchers.IO)
    private lateinit var status: TextView
    private lateinit var out: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("tv", MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24); setBackgroundColor(Color.parseColor("#121212")) }
        val ip = EditText(this).apply { hint = "IP de la télé (ex 192.168.1.50)"; setText(prefs.getString("ip", "")); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        status = TextView(this).apply { text = "Non connecté"; setTextColor(Color.LTGRAY) }
        root.addView(ip)
        root.addView(btn("Connecter") { prefs.edit().putString("ip", ip.text.toString()).apply(); connect(ip.text.toString().trim()) })
        root.addView(status)

        fun row(vararg items: Pair<String, () -> Unit>) = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            items.forEach { (t, a) -> addView(btn(t, a), LinearLayout.LayoutParams(0, -2, 1f)) }
        }
        fun k(c: String): () -> Unit = { shell("input keyevent $c") }

        root.addView(btn("🎤 Commande vocale") {
            try { startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Dites une commande…") }, 42)
            } catch (e: Exception) { toast("Reconnaissance vocale indisponible") }
        })
        root.addView(title("Télécommande"))
        root.addView(row("⏻" to k("KEYCODE_POWER"), "🏠" to k("KEYCODE_HOME"), "↩" to k("KEYCODE_BACK"), "☰" to k("KEYCODE_MENU")))
        root.addView(row("" to {}, "▲" to k("KEYCODE_DPAD_UP"), "" to {}))
        root.addView(row("◀" to k("KEYCODE_DPAD_LEFT"), "OK" to k("KEYCODE_DPAD_CENTER"), "▶" to k("KEYCODE_DPAD_RIGHT")))
        root.addView(row("" to {}, "▼" to k("KEYCODE_DPAD_DOWN"), "" to {}))
        root.addView(row("Vol -" to k("KEYCODE_VOLUME_DOWN"), "Muet" to k("KEYCODE_VOLUME_MUTE"), "Vol +" to k("KEYCODE_VOLUME_UP")))
        root.addView(row("⏮" to k("KEYCODE_MEDIA_PREVIOUS"), "⏯" to k("KEYCODE_MEDIA_PLAY_PAUSE"), "⏭" to k("KEYCODE_MEDIA_NEXT")))
        root.addView(row("Source" to k("KEYCODE_TV_INPUT"), "Réglages" to k("KEYCODE_SETTINGS"), "Apps" to k("KEYCODE_ALL_APPS")))

        root.addView(title("Image"))
        root.addView(row("Réglages image" to { shell("am start -a android.settings.DISPLAY_SETTINGS") },
                         "Lister réglages" to { shell("settings list global; settings list system; settings list secure") }))
        val cmd = EditText(this).apply { hint = "Commande perso (ex: settings put global ... )"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        root.addView(cmd)
        root.addView(btn("Envoyer la commande") { shell(cmd.text.toString()) })
        root.addView(title("Raccourcis perso (appui long = enregistrer la commande ci-dessus)"))
        val names = listOf("Vif", "Standard", "Cinéma", "Sport", "Couleur +", "Couleur -")
        names.chunked(3).forEach { ch ->
            root.addView(LinearLayout(this).apply {
                ch.forEach { n ->
                    val bt = btn(n) { prefs.getString("p_$n", null)?.let { shell(it) } ?: toast("Appui long pour enregistrer") }
                    bt.setOnLongClickListener { prefs.edit().putString("p_$n", cmd.text.toString()).apply(); toast("$n enregistré"); true }
                    addView(bt, LinearLayout.LayoutParams(0, -2, 1f))
                }
            })
        }
        out = TextView(this).apply { setTextColor(Color.GREEN); textSize = 11f; setTextIsSelectable(true) }
        root.addView(out)
        setContentView(ScrollView(this).apply { addView(root) })
        if (ip.text.isNotEmpty()) connect(ip.text.toString().trim())
    }

    private val vocal = listOf(
        listOf("allume", "éteins", "eteins", "power") to "KEYCODE_POWER",
        listOf("monte le son", "plus fort", "volume plus", "augmente") to "KEYCODE_VOLUME_UP",
        listOf("baisse", "moins fort", "volume moins") to "KEYCODE_VOLUME_DOWN",
        listOf("muet", "coupe le son", "silence") to "KEYCODE_VOLUME_MUTE",
        listOf("accueil", "maison") to "KEYCODE_HOME",
        listOf("retour") to "KEYCODE_BACK",
        listOf("pause", "lecture", "play") to "KEYCODE_MEDIA_PLAY_PAUSE",
        listOf("suivant") to "KEYCODE_MEDIA_NEXT",
        listOf("précédent", "precedent") to "KEYCODE_MEDIA_PREVIOUS",
        listOf("source", "entrée", "hdmi") to "KEYCODE_TV_INPUT",
        listOf("haut") to "KEYCODE_DPAD_UP", listOf("bas") to "KEYCODE_DPAD_DOWN",
        listOf("gauche") to "KEYCODE_DPAD_LEFT", listOf("droite") to "KEYCODE_DPAD_RIGHT",
        listOf("ok", "valide", "entrer") to "KEYCODE_DPAD_CENTER",
        listOf("paramètres", "réglages") to "KEYCODE_SETTINGS")

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 42 || res != RESULT_OK) return
        val phrase = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.lowercase() ?: return
        status.text = "Entendu : $phrase"
        val prefs = getSharedPreferences("tv", MODE_PRIVATE)
        // Modes d'image : utilise les raccourcis perso enregistrés
        val modes = mapOf("vif" to "Vif", "standard" to "Standard", "cinéma" to "Cinéma", "cinema" to "Cinéma",
            "sport" to "Sport", "plus de couleur" to "Couleur +", "moins de couleur" to "Couleur -")
        modes.entries.firstOrNull { phrase.contains(it.key) }?.let { (_, n) ->
            prefs.getString("p_$n", null)?.let { shell(it) } ?: toast("Raccourci $n pas encore enregistré"); return }
        val m = Regex("chaîne (\\d+)|chaine (\\d+)").find(phrase)
        if (m != null) { val num = m.groupValues.drop(1).first { it.isNotEmpty() }
            shell(num.map { "input keyevent KEYCODE_$it" }.joinToString("; ")); return }
        val hit = vocal.firstOrNull { (mots, _) -> mots.any { phrase.contains(it) } }
        if (hit != null) shell("input keyevent ${hit.second}") else toast("Commande non reconnue : $phrase")
    }

    private fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { a() }; if (t.isEmpty()) visibility = View.INVISIBLE }
    private fun title(t: String) = TextView(this).apply { text = t; setTextColor(Color.WHITE); textSize = 16f; setPadding(0, 28, 0, 8) }
    private fun toast(m: String) = runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }

    private fun keys(): AdbKeyPair {
        val priv = File(filesDir, "adbkey"); val pub = File(filesDir, "adbkey.pub")
        if (!priv.exists()) AdbKeyPair.generate(priv, pub)
        return AdbKeyPair.read(priv, pub)
    }

    private fun connect(host: String) = scope.launch {
        try {
            runOnUiThread { status.text = "Connexion… acceptez la demande sur la télé" }
            adb?.close()
            adb = Dadb.create(host, 5555, keys())
            adb!!.shell("echo ok")
            runOnUiThread { status.text = "Connecté à $host" }
        } catch (e: Exception) { adb = null; runOnUiThread { status.text = "Erreur : ${e.message}" } }
    }

    private fun shell(c: String) {
        if (c.isBlank()) return
        val d = adb ?: return toast("Pas connecté")
        scope.launch {
            try { val r = d.shell(c).allOutput; runOnUiThread { out.text = r.take(6000) } }
            catch (e: Exception) { runOnUiThread { status.text = "Erreur : ${e.message}" } }
        }
    }
}
